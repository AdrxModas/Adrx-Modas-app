# Financeiro — retirada via Pix

## Regra definida para a Adrx.Modas
- O Admin guarda somente a chave Pix de destino e, opcionalmente, titular/banco.
- Senha bancária, token, código SMS/2FA e credenciais do banco nunca são armazenados.
- O Itachi acompanha os valores registrados no financeiro e audita as solicitações.
- Fluxo: solicitar retirada → Itachi registra → proprietário libera → proprietário faz o Pix no banco → proprietário marca como realizado → caixa registrado é atualizado.
- O protótipo não executa Pix diretamente. Uma integração bancária real exigiria API oficial do banco, autenticação forte e backend seguro.

## Segurança
A chave Pix aparece mascarada no histórico. A autorização e a confirmação ficam registradas na auditoria local do protótipo e devem ser migradas para logs server-side/imutáveis quando o backend for conectado.

# Android — Adrx.Modas

A V17 está preparada para ser empacotada como dois apps Android independentes usando Capacitor:

- Cliente: `com.adrxmodas.cliente`
- Admin: `com.adrxmodas.admin`

## Build
1. Instale Node.js LTS e Android Studio.
2. Na raiz, rode `npm install`.
3. Para cada app, adicione/sincronize a plataforma Android com Capacitor.
4. Abra o projeto Android no Android Studio.
5. Gere APK para testes e AAB assinado para Google Play.

A publicação real exige uma conta Google Play e assinatura de release. Não coloque chaves, senhas ou secrets no código.

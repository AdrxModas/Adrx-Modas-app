# Adrx.Modas — preparação para produção

## Estrutura
- `/cliente` = aplicativo público do cliente
- `/admin` = painel administrativo separado
- `/supabase/schema.sql` = base inicial do banco + RLS
- `.env.example` = variáveis públicas do cliente
- `vercel.json` = headers e rotas básicas

## Publicação
1. Criar projeto Supabase.
2. Executar `supabase/schema.sql` no SQL Editor.
3. Criar projeto Vercel apontando para esta pasta.
4. Configurar `VITE_SUPABASE_URL` e `VITE_SUPABASE_ANON_KEY` no ambiente do Vercel.
5. Não colocar `service_role` ou qualquer segredo privilegiado no código do cliente.
6. Configurar autenticação do cliente e do admin separadamente, usando o mesmo backend.
7. Criar o primeiro usuário owner no Supabase e habilitá-lo em `admin_members`.
8. Testar RLS com contas de cliente e de admin antes de abrir a loja.
9. Configurar domínio/HTTPS e, depois, instalar como PWA no celular.

## Ainda precisa de integração real
A V16 é um protótipo funcional local. Para produção, as funções hoje baseadas em armazenamento local precisam ser migradas para o Supabase: clientes, pedidos, estoque, favoritos, avaliações, notificações, permissões e auditoria.

Biometria deve usar Passkeys/WebAuthn do dispositivo; não armazenar fotos de rosto ou impressões digitais.

## Checklist antes de abrir
- [ ] Supabase criado
- [ ] RLS testado
- [ ] Auth de cliente testado
- [ ] Auth de admin testado
- [ ] Primeiro owner criado
- [ ] Pedidos persistindo no banco
- [ ] Estoque persistindo no banco
- [ ] Auditoria persistindo no banco
- [ ] Recuperação de senha testada
- [ ] Backup/recovery definido
- [ ] Domínio/HTTPS configurado
- [ ] Teste em Android real

# Adrx.Modas — App V2 (protótipo funcional)

Esta versão transforma a base anterior em um protótipo funcional com duas áreas separadas:

- `cliente/` — loja/app do cliente.
- `admin/` — painel administrativo da loja.

## O que já funciona

### Loja do cliente
- 4 produtos atuais: Egeo Dolce, Arbo, Nativa SPA Ameixa e Cuide-se Bem Nuvem.
- Fotos reais já incluídas no projeto.
- Busca e filtros.
- Carrinho com quantidade.
- Cadastro de cliente.
- Finalização de pedido.
- Número de pedido sequencial (#000001, #000002...).
- Estoque reduzido automaticamente após pedido concluído.
- Histórico de pedidos.
- Botão Shopee marcado como “em breve”.
- Regra preparada para considerar atividade do cadastro por compra concluída.
- PWA básico (pode ser instalado no celular quando hospedado).

### Painel Admin
- Dashboard de pedidos, vendas, clientes e estoque.
- Lista de pedidos.
- Clientes contabilizados por compras concluídas.
- Edição de estoque.
- Impressão da **etiqueta/resumo de entrega** sem mostrar os produtos.
- Impressão de **comprovante A4** com os produtos.

## Importante
Esta V2 ainda usa `localStorage` do navegador. Portanto, ela é ótima para testar o fluxo, mas **não é ainda um sistema online compartilhado** entre aparelhos.

Para a versão real online, a próxima etapa é:

`Adrx.Modas → Supabase (clientes/pedidos/estoque) → Vercel (hospedagem) → Bling (fiscal/estoque oficial, quando fizer sentido)`

Não há integração com Bling nesta versão e nenhuma credencial é embutida no projeto.

## Como testar

Abra `cliente/index.html` para a loja e `admin/index.html` para o painel. Para testar o compartilhamento no navegador, o ideal é servir a pasta inteira por um servidor local (por exemplo, Live Server) para que as duas áreas estejam no mesmo domínio/origem.

## Fiscal
O comprovante A4 e a etiqueta são documentos internos da loja. Eles **não substituem NF-e/NFC-e oficial**.

## V14 — reforço de segurança
- Senha forte individual para cada cliente no protótipo local.
- PBKDF2-SHA-256 + salt aleatório para derivação local da senha.
- Sessão protegida para conta e pedidos.
- Bloqueio temporário após tentativas incorretas.
- Registro local de eventos de segurança do cliente.
- Bloqueio manual da conta no dispositivo.
- Invalidação local de cadastro após mais de 7 meses sem compra concluída.
- Painel administrativo reforçado com derivação de credencial, bloqueio após tentativas, sessão com expiração por inatividade e migração da credencial legada.
- Itachi continua como administrador/monitor do painel, sem poder destrutivo irrestrito.
- A segurança definitiva continua dependendo do backend (Supabase Auth/RLS, rate limiting, MFA opcional, auditoria server-side e segredos fora do cliente).

## V20 — fechamento do desenvolvimento
A versão V20 consolida o cliente + Admin da V19, adiciona ícones Android/PWA oficiais, atualiza a versão do projeto para 20.0.0 e inclui `supabase/schema_v20_additions.sql` com operações críticas server-side (pedido atômico, estoque e estruturas financeiras/auditoria).
Consulte `V20_PRODUCAO.md` para o que ainda precisa ser conectado antes do uso comercial.

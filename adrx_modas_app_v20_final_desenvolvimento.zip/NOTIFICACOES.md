# Notificações — Adrx.Modas V5

A V5 adiciona:
- pedido de permissão para notificações no app do cliente;
- status de notificações;
- avisos locais de ofertas para dispositivos que autorizaram notificações;
- botão de aviso no painel administrativo;
- estrutura PWA/service worker preparada.

## Limitação atual
O projeto ainda funciona com armazenamento local. Portanto, a V5 não consegue enviar uma notificação push para todos os clientes de dispositivos diferentes.

Para isso, a próxima etapa é conectar Supabase (ou outro serviço de push), salvar as subscriptions dos clientes e fazer o admin enviar uma oferta pelo backend.

Não existe envio automático ou cobrança de serviço escondida nesta V5.

-- Adrx.Modas V20 — operações críticas server-side
-- Executar DEPOIS de schema.sql no Supabase.

create table if not exists public.finance_entries (
  id uuid primary key default gen_random_uuid(),
  kind text not null check (kind in ('sale','cost','stock','adjustment','withdrawal')),
  amount numeric(12,2) not null check (amount >= 0),
  order_id uuid references public.orders(id) on delete set null,
  description text not null default '',
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists public.pix_destinations (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  pix_key text not null,
  holder_name text,
  bank_name text,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.withdrawals (
  id uuid primary key default gen_random_uuid(),
  amount numeric(12,2) not null check (amount > 0),
  pix_destination_id uuid references public.pix_destinations(id) on delete restrict,
  status text not null default 'requested' check (status in ('requested','authorized','completed','cancelled')),
  requested_by uuid references auth.users(id) on delete set null,
  authorized_by uuid references auth.users(id) on delete set null,
  completed_by uuid references auth.users(id) on delete set null,
  requested_at timestamptz not null default now(),
  authorized_at timestamptz,
  completed_at timestamptz,
  note text
);

create table if not exists public.security_events (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid references auth.users(id) on delete set null,
  event_type text not null,
  severity text not null default 'normal' check (severity in ('normal','warning','critical')),
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index if not exists finance_created_idx on public.finance_entries(created_at desc);
create index if not exists withdrawals_status_idx on public.withdrawals(status, requested_at desc);
create index if not exists security_created_idx on public.security_events(created_at desc);

alter table public.finance_entries enable row level security;
alter table public.pix_destinations enable row level security;
alter table public.withdrawals enable row level security;
alter table public.security_events enable row level security;

create policy "admin finance read" on public.finance_entries for select using (public.is_admin(auth.uid()));
create policy "admin pix read" on public.pix_destinations for select using (owner_id=auth.uid() or public.is_admin(auth.uid()));
create policy "owner pix write" on public.pix_destinations for all using (owner_id=auth.uid()) with check (owner_id=auth.uid());
create policy "admin withdrawals read" on public.withdrawals for select using (public.is_admin(auth.uid()));
create policy "owner security read" on public.security_events for select using (actor_id=auth.uid() or public.is_admin(auth.uid()));

-- Cria pedido atomicamente, recalculando preços e estoque no servidor.
create or replace function public.create_order(p_items jsonb, p_delivery_address jsonb)
returns public.orders
language plpgsql
security definer
set search_path=public
as $$
declare
  v_user uuid := auth.uid();
  v_order public.orders;
  v_item jsonb;
  v_product public.products;
  v_total numeric(12,2) := 0;
  v_qty integer;
begin
  if v_user is null then raise exception 'AUTH_REQUIRED'; end if;
  if jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items)=0 then raise exception 'EMPTY_ORDER'; end if;

  insert into public.orders(user_id,status,payment_status,total,delivery_address)
  values(v_user,'received','pending',0,p_delivery_address)
  returning * into v_order;

  for v_item in select * from jsonb_array_elements(p_items) loop
    v_qty := greatest(1, (v_item->>'quantity')::integer);
    select * into v_product from public.products where id=(v_item->>'product_id')::uuid and active=true for update;
    if not found then raise exception 'PRODUCT_NOT_FOUND'; end if;
    if v_product.stock < v_qty then raise exception 'INSUFFICIENT_STOCK:%', v_product.name; end if;

    insert into public.order_items(order_id,product_id,product_name,unit_price,quantity)
    values(v_order.id,v_product.id,v_product.name,v_product.price,v_qty);
    update public.products set stock=stock-v_qty, updated_at=now() where id=v_product.id;
    v_total := v_total + (v_product.price * v_qty);
  end loop;

  update public.orders set total=v_total,updated_at=now() where id=v_order.id returning * into v_order;
  insert into public.audit_logs(actor_id,action,target_type,target_id,details)
  values(v_user,'ORDER_CREATED','order',v_order.id::text,jsonb_build_object('total',v_total));
  return v_order;
exception when others then
  delete from public.orders where id=v_order.id;
  raise;
end;
$$;

revoke all on function public.create_order(jsonb,jsonb) from public;
grant execute on function public.create_order(jsonb,jsonb) to authenticated;

-- Avaliação só pode nascer de uma compra entregue que contenha o produto.
create or replace function public.can_review(p_product uuid, p_order uuid)
returns boolean language sql stable security definer set search_path=public
as $$
select exists(
  select 1 from public.orders o
  join public.order_items oi on oi.order_id=o.id
  where o.id=p_order and o.user_id=auth.uid() and o.status='delivered' and oi.product_id=p_product
);
$$;

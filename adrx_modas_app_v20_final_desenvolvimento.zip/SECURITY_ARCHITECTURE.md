# Adrx.Modas — Segurança do Admin / Itachi

## O que a V9 faz no protótipo
- Área exclusiva do proprietário com bloqueio de sessão.
- Chave local de acesso com mínimo de 6 caracteres.
- Registro de login, logout, tentativas negadas e alterações no histórico de auditoria.
- Confirmação antes de alterações sensíveis feitas pelo Itachi no chat.
- Itachi consegue preparar alterações de estoque/preço pelo chat, mas só executa após confirmação.
- Eventos suspeitos ficam registrados para análise.
- Modo claro, texto maior e alto contraste.
- Área interna de sugestões de melhorias.

## Limite importante
O navegador não consegue oferecer segurança absoluta. Um usuário que controla o próprio dispositivo pode abrir DevTools, alterar JavaScript/localStorage ou modificar os arquivos. A trava local é uma proteção de interface, não uma barreira criptográfica.

## Segurança real para Vercel + Supabase
Na publicação, as regras críticas devem existir no servidor/banco:

1. Supabase Auth para login do proprietário e membros da equipe.
2. MFA para o proprietário.
3. RLS em todas as tabelas; cada operação deve validar `user_id`, `store_id` e papel.
4. Permissões por função/canal: proprietário, gerente, estoque, Shopee, TikTok, Kwai etc.
5. Service Role Key somente no backend; nunca no JavaScript do navegador.
6. Rate limit e proteção contra tentativas repetidas de login/API.
7. Validação de todos os valores no servidor, inclusive preço, estoque e status do pedido.
8. Auditoria imutável no servidor para login, alterações de preço/estoque, permissões, pedidos e integrações.
9. Sessões com expiração e revogação; cookies HttpOnly/Secure/SameSite quando aplicável.
10. Proteção contra CSRF quando houver autenticação baseada em cookies.
11. CSP, HSTS e demais cabeçalhos de segurança configurados no servidor/hosting.
12. Backups e recuperação de banco testados.
13. Alertas para comportamento anormal: muitas falhas de login, mudanças em massa, exportações incomuns e alterações de permissões.
14. Nunca realizar contra-ataque, payload malicioso ou corrupção do invasor. O sistema deve bloquear, registrar e preservar evidências.

## Princípio do Itachi
Itachi pode observar, explicar e executar tarefas operacionais autorizadas. Ações destrutivas, permissões, autenticação, dinheiro e integrações críticas permanecem sob controle do proprietário e do backend.

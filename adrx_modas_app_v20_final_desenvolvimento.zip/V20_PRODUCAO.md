# Adrx.Modas V20 — estado do projeto

Esta versão consolida a interface V19 e adiciona a base server-side das operações críticas.

## O que está pronto no pacote
- App cliente separado do Admin.
- Catálogo atual com Egeo Dolce, Arbo, Nativa SPA Ameixa e Cuide-se Bem Nuvem.
- Favoritos, avaliações, carrinho, pedidos, notificações e Assistente Adrx em modo local/protótipo.
- Admin com dashboard, estoque, pedidos, manutenção, financeiro, retirada Pix, auditoria e Itachi.
- Manifesto PWA e projetos Capacitor preparados para Android.
- `supabase/schema.sql` + `supabase/schema_v20_additions.sql` para a camada de dados.

## O que precisa ser conectado antes de vender de verdade
1. Criar o projeto Supabase e aplicar os dois SQLs.
2. Implementar autenticação real (email/senha + passkey/WebAuthn no backend).
3. Trocar as rotinas localStorage do cliente/Admin pelas consultas/RPC do Supabase.
4. Colocar regras sensíveis em Edge Functions/RPC; nunca colocar service_role no app.
5. Configurar Vercel para as rotas de backend e variáveis públicas/privadas corretamente.
6. Configurar push notifications se forem necessárias quando o app estiver fechado.
7. Fazer testes de segurança, concorrência de estoque, sessão, permissões e recuperação de conta.
8. Só depois distribuir o APK assinado para clientes.

## Financeiro/Pix
O app registra valores e autorização. O Pix bancário continua sendo feito/confirmado pelo proprietário no banco. Nenhuma senha, token, 2FA ou credencial bancária deve ser armazenada no app.

## Importante
O comprovante gerado pelo app é um comprovante de pedido. Ele não substitui NF-e/NFC-e nem autorização fiscal da SEFAZ.

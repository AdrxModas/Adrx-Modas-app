# Separação Cliente/Admin — V15

A pasta cliente e a pasta admin representam dois aplicativos independentes:

- Cliente: `/cliente/index.html` — público.
- Admin: `/admin/index.html` — privado.

Em produção, publicar em origens/rotas independentes e compartilhar somente API/backend.

Exemplo conceitual:
- loja.adrx.modas → cliente
- admin.adrx.modas → admin
- api.adrx.modas → backend compartilhado

O admin deve exigir autenticação forte antes de entregar qualquer dado administrativo. O cliente deve receber apenas dados públicos e os próprios dados autenticados.

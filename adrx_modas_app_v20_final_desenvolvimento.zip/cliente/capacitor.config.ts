import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = {
  appId: 'com.adrxmodas.cliente',
  appName: 'Adrx.Modas',
  webDir: '.',
  bundledWebRuntime: false,
  server: { androidScheme: 'https' }
};
export default config;

# Segurança da conta do cliente — Adrx.Modas

## Implementado no protótipo
- Senha mínima de 12 caracteres.
- Exigência de maiúscula, minúscula, número e símbolo.
- Derivação PBKDF2-SHA-256 com salt aleatório por conta e 210.000 iterações.
- Senha não é salva em texto puro.
- Sessão separada para o cliente.
- Bloqueio temporário após 5 tentativas incorretas.
- Eventos locais de login, falha e bloqueio.
- Bloqueio manual da conta no dispositivo.
- Conta e pedidos exigem sessão autenticada quando a senha está configurada.

## Antes de publicar
Esta é uma proteção de protótipo local. localStorage/sessionStorage podem ser alterados por alguém com acesso ao navegador. A proteção real deve ser repetida no backend, por exemplo com Supabase Auth + RLS, sessões seguras, recuperação de senha por e-mail, rate limiting server-side, MFA opcional e auditoria no servidor.

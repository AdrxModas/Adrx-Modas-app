# Adrx.Modas V16 — experiência e operação

Base: V15 com cliente/admin separados.

## Cliente
- ordenação por preço/nome e filtro de disponibilidade;
- produtos vistos recentemente;
- recomendações simples locais;
- compartilhar/copiar link do produto;
- indicação de últimas unidades;
- mantém carrinho, checkout, pedidos, favoritos, avaliações, notificações, conta e senha forte da V15.

## Admin
- status visual da loja;
- visão rápida de mais vendidos;
- estoque baixo/crítico;
- atalhos operacionais no dashboard;
- mantém Itachi, financeiro, auditoria, contas, acessibilidade e segurança da V15.

## Importante
Esta versão continua sendo um protótipo local. Persistência real entre dispositivos, autenticação, pagamentos, notificações push e segurança efetiva precisam do backend planejado (ex.: Supabase/Vercel).

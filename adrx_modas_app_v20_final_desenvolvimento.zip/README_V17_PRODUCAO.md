# Adrx.Modas V17 — produção

Esta versão mantém a experiência visual da V16 e acrescenta os arquivos necessários para preparar a publicação real.

**Importante:** ela não é declarada como loja de produção até que o backend Supabase seja conectado e as políticas/RLS sejam testadas.

# Próxima etapa — Adrx.Modas online

1. Criar projeto Supabase.
2. Criar tabelas de clientes, pedidos, itens de pedido, produtos e eventos de atividade.
3. Migrar o localStorage para banco de dados.
4. Criar autenticação real do cliente.
5. Criar autenticação independente do Admin.
6. Criar API server-side na Vercel.
7. Conectar Bling por OAuth 2.0 somente no backend.
8. Sincronizar estoque/pedidos com o Bling quando a operação estiver pronta.
9. Adicionar emissão fiscal via fluxo oficial do sistema fiscal.

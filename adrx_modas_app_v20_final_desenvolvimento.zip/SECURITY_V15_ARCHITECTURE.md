# Adrx.Modas V15 — arquitetura de segurança

## Dois aplicativos, um backend
- `/cliente/`: aplicativo público do cliente.
- `/admin/`: aplicativo privado administrativo.
- Ambos devem usar o mesmo backend/API e banco, mas com autenticação, sessões e permissões separadas.
- O cliente nunca recebe chaves administrativas.
- O admin nunca deve confiar em validações feitas apenas no navegador.

## Contas administrativas
O proprietário pode autorizar contas adicionais (ex.: namorada/equipe/amigos) com funções específicas. O Itachi registra criação, autorização, revogação e eventos de acesso.

### Biometria / Face ID / digital
Não armazenar fotos do rosto, templates faciais ou digitais no banco do Itachi. A implementação correta é WebAuthn/Passkeys:
- o aparelho faz a verificação biométrica local;
- o servidor recebe apenas a credencial criptográfica pública e metadados necessários;
- cada conta pode ter uma ou mais passkeys;
- revogação deve ser possível pelo proprietário;
- exigir passkey + sessão autenticada para acesso administrativo sensível.

A interface da V15 está preparada para esse fluxo. A validação criptográfica real depende do backend.

## Itachi
O Itachi funciona como camada de análise/assistência, não como fronteira única de segurança. Pode analisar:
- login e falhas;
- sessões e dispositivos;
- mudanças de estoque/preço;
- pedidos;
- alterações administrativas;
- eventos anômalos;
- criação/revogação de contas.

Ações críticas continuam sujeitas a permissões e confirmação do proprietário.

## Cliente
O cliente usa senha forte e sessão. No backend, armazenar somente hash seguro da senha (Argon2id ou equivalente), salt e metadados de autenticação. Nunca guardar senha em texto puro.

## Backend recomendado
Supabase Auth + RLS + Edge Functions/servidor, com rate limiting, logs de auditoria, expiração de sessão, recuperação de conta, MFA/passkeys e backups.

## Desempenho
Os dois apps devem ser carregados separadamente, com assets locais, lazy-loading de imagens, cache do catálogo e service worker no cliente. O admin não deve ser carregado junto com o app público.

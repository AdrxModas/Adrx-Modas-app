import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = {
  appId: 'com.adrxmodas.admin',
  appName: 'Adrx.Modas Admin',
  webDir: '.',
  bundledWebRuntime: false,
  server: { androidScheme: 'https' }
};
export default config;
